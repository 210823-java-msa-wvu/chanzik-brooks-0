package brooks.revature.shoes;

public class User {
    private Integer id;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private Customer customer;
    private Employee employee;
    boolean isLoggedIn = false;

    public User() {

    }

    public User(String firstName, String lastName, String userName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
    }

    public User(Customer c, String firstName, String lastName, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.customer = c;
        this.password = password;
    }

    public User(Employee e, String firstName, String lastName, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.employee = e;
        this.password = password;
    }

    /*
     * Retrieves id
     */
    public Integer getId() {
        return id;
    }

    /*
     * Sets id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /*
     * Retrieves first name
     */
    public String getFirstName() {
        return firstName;
    }

    /*
     * Sets first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /*
     * Retrieves last name
     */
    public String getLastName() {
        return lastName;
    }

    /*
     * Sets last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /*
     * Retrieves username
     */
    public String getUserName() {
        return this.userName;
    }

    /*
     * Sets username
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /*
     * Retrieves password
     */
    public String getPassword() {
        return password;
    }

    /*
     * Sets password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /*
     * Returns logged in as false unless set to ture
     */
    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    /*
     * Set users' logged in state as true or false
     */
    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }

    /*
     * Stores username of user
     */
    public String toString() {
        return "Hello: " + this.userName;
    }



}

