package brooks.revature.models;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class playground {

    public static void main(String[] args) {
        HomePage home = new HomePage();
        Scanner sc = new Scanner(System.in);
        String userFirst = "";
        String userLast = "";
        String userName = "";
        String password = "";
        String userResponse = "";



        List<Customer> listOfCustomers = new ArrayList<Customer>();
        List<Employee> listOfEmployees = new ArrayList<>();
        List<User> listOfUsers = new ArrayList<>();


        try {
            //while (isRunning)
            boolean isRunning = true;
            do {
                home.displayHome();

                System.out.println("Total users: " + listOfUsers.size());
                int userInput1 = sc.nextInt();
                String userInput2 = sc.nextLine();







                if(userInput1 == 1) {
                    System.out.println("Username: ");
                    userName = sc.nextLine();
                    System.out.println("Password: ");
                    password = sc.nextLine();
                    System.out.println();

                    if(listOfUsers.isEmpty()) {
                        System.out.println("This user does not exist.");
                        System.out.println();
                    } else {
                        for(int i = 0; i < listOfUsers.size(); i++) {
                            if(listOfUsers.get(i).getUserName().equals(userName)
                                    && listOfUsers.get(i).getPassword().equals(password)) {

                                listOfUsers.get(i).setLoggedIn(true);
                                System.out.println("You are logged in.");
                                System.out.println();
                            }
                            else if(listOfUsers.isEmpty()) {
                                System.out.println("You have entered an incorrect Username or Paasword.");
                                System.out.println("Please create an account.");
                                System.out.println();
                            }
                            else {
                                System.out.println("You have entered an incorrect Username or Paasword.");
                                System.out.println();
                            }
                        }
                    }




                    //if user chooses to create an account
                }
                else if (userInput1 == 2){
                    try {

                        System.out.println("First Name: ");
                        userFirst = sc.nextLine();
                        System.out.println("Last Name: ");
                        userLast = sc.nextLine();
                        System.out.println("Username: ");
                        userName = sc.nextLine();
                        System.out.println("Password: ");
                        password = sc.nextLine();


                        System.out.println("Are you an employee at this bank? Please enter yes or no.");
                        userResponse = sc.nextLine();
                        if(userResponse.equals("no")) {
                            User c = new Customer(userFirst, userLast);
                            c.setUserName(userName);
                            c.setPassword(password);
                            listOfUsers.add(c);
                            System.out.println(listOfUsers.get(listOfUsers.size() - 1).toString());
                            System.out.println();
                        }
                        else if(userResponse.equals("yes")) {
                            User e = new Employee(userFirst, userLast);
                            e.setUserName(userName);
                            e.setPassword(password);
                            listOfUsers.add(e);
                            System.out.println(listOfUsers.get(listOfUsers.size() - 1).toString());
                            System.out.println();
                        } else {
                            System.out.println("not working");

                        }
                    } catch(Exception e) {

                    }



                }/////
                else if(userInput1 == 3) {
                    System.out.println("Goodbye");
                    isRunning = false;
                    sc.close();
                }
                else {
                    System.out.println("Please press 1 for option 1 or press 2 for option 2.");
                    System.out.println("Press 3 to exit..");

                }
            }
            while(isRunning == true);

        } catch(InputMismatchException e) {
            System.out.println("Mismatch error. Please recheck input.");
        }











    }
}
