package brooks.revature.models;

public class User {
    private Integer id;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private Customer customer;
    private Employee employee;
    private String isEmployee = "no";
    private boolean isLoggedIn = false;
    private int funds;

    /*
     * Default constructor
     */
    public User() {

    }

    /*
     * This constructor is used in project 0
     */
    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    /*
     * This constructor is used in project 0
     */
    public User(Integer id, String userName, String password) {
        this.id = id;
        this.userName = userName;
        this.password = password;
    }


    /*
     * This constructor is used in project 0
     */
    public User(String username, String password, String firstName, String lastName, String isEmployee) {
        this.userName = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.isEmployee = isEmployee;
    }


    public User(int id, String userName, String password, String firstName, String lastName, String employee, int funds) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.funds = funds;
    }

    public User(int id, String username, String password, String firstName, String lastName, String employee,
                int funds, boolean isLoggedIn) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = username;
        this.password = password;
        this.isEmployee = employee;
        this.funds = funds;
    }

    /*
     * Retrieves id
     */
    public Integer getId() {
        return id;
    }

    /*
     * Sets id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /*
     * Retrieves first name
     */
    public String getFirstName() {
        return firstName;
    }

    /*
     * Sets first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /*
     * Retrieves last name
     */
    public String getLastName() {
        return lastName;
    }

    /*
     * Sets last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /*
     * Retrieves username
     */
    public String getUserName() {
        return this.userName;
    }

    /*
     * Sets username
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /*
     * Retrieves password
     */
    public String getPassword() {
        return password;
    }

    /*
     * Sets password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /*
     * Returns logged in as false unless set to ture
     */
    public String getEmployeeStatus() {
        return isEmployee;
    }

    /*
     * Set users' logged in state as true or false
     */
    public void setEmployeeStatus(String isEmployee) {
        this.isEmployee = isEmployee;
    }


    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }

    public int getFunds() {
        return funds;
    }

    public void setFunds(int funds) {
        this.funds = funds;
    }

    /*
     * Stores username of user
     */
    public String toString() {
        return this.userName;
    }



}

