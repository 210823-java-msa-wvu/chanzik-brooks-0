package brooks.revature.services;

import brooks.revature.models.User;
import brooks.revature.repositories.UserRepo;

public class UserServices {

    UserRepo userRepo =  new UserRepo();

    public boolean login(String username, String password ) {

        User u = userRepo.getByUsername(username);

        if (u != null) {
            if(username.equals(u.getUserName()) && password.equals(u.getPassword())) {
                return true;
            }
        }

        return false;
    }

    public void accountCreation(String username, String password, String firstName, String lastName, String isEmployee) {
        User myUser = new User(username, password, firstName, lastName, isEmployee);
        userRepo.add(myUser);

        if(isEmployee.equals("y") || isEmployee.equals("yes")) {
            myUser.setEmployee("yes");
        }
        else if(isEmployee.equals("n") || isEmployee.equals("no")){
            myUser.setEmployee("no");
        }
        else {
            System.out.println("Please enter yes or no.");
        }
    }
}
