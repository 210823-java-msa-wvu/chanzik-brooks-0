package brooks.revature.services;

import brooks.revature.models.User;
import brooks.revature.repositories.UserRepo;

public class UserServices {

    UserRepo userRepo =  new UserRepo();

    public boolean login(String username, String password ) {

        User u = userRepo.getByUsername(username);
        //u.setLoggedIn(true);

        if (u != null) {
            if(username.equals(u.getUserName()) && password.equals(u.getPassword())) {
                return true;
            }
        }

        return false;
    }

    public void accountCreation(String username, String password, String firstName, String lastName, String isEmployee) {

        User myUser = new User(username, password, firstName, lastName, isEmployee);

        myUser.setLoggedIn(true);

        userRepo.add(myUser);

        if(isEmployee.equals("y") || isEmployee.equals("yes")) {
            myUser.setEmployeeStatus("yes");
        }
        else if(isEmployee.equals("n") || isEmployee.equals("no")){
            myUser.setEmployeeStatus("no");
        }
        else {
            System.out.println("Please enter yes or no.");
        }
    }

    public int displayFunds(String username) {
        User u = userRepo.getByUsername(username);
        return u.getFunds();
    }

    public void addFunds(Integer funds, String username) {
        User u = userRepo.getByUsername(username);
        userRepo.addFunds(funds + u.getFunds(), username);
    }

    public void deleteAccount() {
        userRepo.delete(1);
    }
}
