package brooks.revature.app;

import brooks.revature.services.UserServices;

import java.util.Scanner;

public class AppDriver {

    private static UserServices userServices = new UserServices();

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        boolean isRunning = true;

        do {
            System.out.println("Hello. Please log in ");
            System.out.println("1) Log In");
            System.out.println("2) Create An Account");
            System.out.println("3) Display Inventory");
            System.out.println("4) Sell Shoes");
            System.out.println("5) Logout");
            System.out.println("6) Exit");

            int userInput = sc.nextInt();

            switch (userInput) {
                // this will be the login service
                case 1: {
                    // to clear anything in input stream
                    sc.nextLine();

                    System.out.println("Enter username: ");
                    String username = sc.nextLine();

                    System.out.println("Enter password: ");
                    String password = sc.nextLine();
                    boolean signInResponse = userServices.login(username, password);

                    if(signInResponse) {
                        System.out.println("Successful login.");
                        System.out.println();
                        System.out.println("Hello " + username);
                        System.out.println();
                        System.out.println("Current funds: " );
                        int myFunds = userServices.displayFunds(username);
                        System.out.println("$" + myFunds);
                        System.out.println();
                        System.out.println("Would you like to add funds? Enter yes or no");
                        String response = sc.nextLine();

                        if (response.equals("y") || response.equals("yes")) {
                            // call method to add funds
                            System.out.println("Enter whole number amount:");
                            int amount = sc.nextInt();
                            userServices.addFunds(amount, username);
                            System.out.println("New Total funds: $" + (myFunds + amount));
                            System.out.println();

                        }
                        else if(response.equals("n") || response.equals("no")){
                            System.out.println("Sending you back to main menu.");
                            System.out.println();
                        }
                        else {
                            System.out.println("Please enter yes or no.");
                        }

                    }
                    else {
                        System.out.println("Login not successful.");
                        System.out.println("Credentials do not match.");
                        System.out.println();
                    }


                    break;
                }
                case 2: {
                    sc.nextLine();
                    System.out.println("Enter a username:");
                    String username = sc.nextLine();

                    System.out.println("Enter a password:");
                    String password = sc.nextLine();

                    System.out.println("Enter first name:");
                    String firstName = sc.nextLine();

                    System.out.println("Enter last name:");
                    String lastName = sc.nextLine();

                    System.out.println("Do you work for this company? Enter yes or no.");
                    String isEmployee = sc.nextLine();
                    userServices.accountCreation(username, password, firstName, lastName, isEmployee);
                    System.out.println("You have created an account");
                    System.out.println();
                    break;
                }
                case 3: {
                    sc.nextLine();


                }
                case 4: {
                    sc.nextLine();
                    System.out.println("Add shoes information.");
                    System.out.println("Brand: ");
                    String brand = sc.nextLine();
                    System.out.println("Name: ");
                    String name = sc.nextLine();
                    System.out.println("Color:");
                    String color = sc.nextLine();
                    System.out.println("Category: (Enter one of these options: Men, Women, or kids)");
                    String category = sc.nextLine();
                    System.out.println("Size:");
                    int size = sc.nextInt();
                    System.out.println("Price:");
                    int price = sc.nextInt();
                    userServices.addShoes(brand, name, color, category, size, price);
                    System.out.println("Your shoes have been added.");
                    System.out.println();
                    break;
                }
                case 5: {
                    sc.nextLine();
                    System.out.println("Enter username ");
                    String username = sc.nextLine();
                    System.out.println("Enter password ");
                    String password = sc.nextLine();
                    userServices.logout(username, password);
                    System.out.println("You are logged out");
                    System.out.println();
                    break;

                }
                case 6: {
                    System.out.println("Thanks for coming.");
                    isRunning = false;
                    break;
                }

            }
        } while (isRunning);


    }
}
