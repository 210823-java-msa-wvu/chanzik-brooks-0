package brooks.revature.app;

import brooks.revature.services.UserServices;

import java.util.Scanner;

public class AppDriver {

    private static UserServices userServicess = new UserServices();

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);

        System.out.println("Hello. Please log in ");
        System.out.println("1) Log In");
        System.out.println("2) Create An Account");
        System.out.println("3) Exit");

        int userInput = sc.nextInt();

        switch (userInput) {
            // this will be the login service
            case 1: {
                // to clear anything in input stream
                sc.nextLine();

                System.out.println("Enter username: ");
                String username = sc.nextLine();

                System.out.println("Enter password: ");
                String password = sc.nextLine();
                boolean signInResponse = userServicess.login(username, password);

                if(signInResponse) {
                    System.out.println("Successful login.");

                }
                else {
                    System.out.println("Login not successful.");
                    System.out.println("Credentials do not match.");

                }
                break;
            }
            case 2: {
                sc.nextLine();
                System.out.println("Enter a username:");
                String username = sc.nextLine();

                System.out.println("Enter a password:");
                String password = sc.nextLine();

                System.out.println("Enter first name:");
                String firstName = sc.nextLine();

                System.out.println("Enter last name:");
                String lastName = sc.nextLine();

                System.out.println("Do you work for this company? Enter yes or no.");
                String isEmployee = sc.nextLine();
                userServicess.accountCreation(username, password, firstName, lastName, isEmployee);
                break;
            }
            case 3: {
                System.out.println("Thanks for coming.");
                break;
            }

        }
    }
}
