package brooks.revature.repositories;

import brooks.revature.models.User;
import brooks.revature.utils.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Class will define methods to interact with our database.
 * C - Create
 * R _ Read
 * U - Update
 * D - Delete
 */
public class UserRepo implements CrudRepository<User>{
    private ConnectionUtil cu = ConnectionUtil.getConnectionUtil();

    //Create
    public User add(User u) {
        try (Connection conn = cu.getConnection()) {
            String sql = "insert into users values(default, ?, ?, ?, ?, ?) returning *";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, u.getUserName());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFirstName());
            ps.setString(4, u.getLastName());
            ps.setString(5, u.isEmployee());


            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                u.setId(rs.getInt("id"));

            }

        } catch(SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public User getById(Integer id) {
        try (Connection conn = cu.getConnection()) {

            String sql = "select * from users where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                User u = new User();

                u.setId(rs.getInt("id"));
                u.setFirstName(rs.getString("first_name"));
                u.setLastName(rs.getString("last_name"));

                return u;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User getByUsername(String username) {

        try (Connection conn = cu.getConnection()) {

            String sql = "select * from users where username = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User u = new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password")
                );
                return u;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }


    public List getAll() {ArrayList<User> a = new ArrayList();

        try (Connection conn = cu.getConnection()) {
            String sql = "select * from users";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                User u = new User(rs.getInt("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name")
                );

                a.add(u);
            }


        } catch(SQLException e) {
            e.printStackTrace();
        }

        return null;
    }


    public void update(User u) {
        try (Connection conn = cu.getConnection()) {
            String sql = "update users set first_name = ?, last_name = ?, where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, u.getFirstName());
            ps.setString(2, u.getLastName());
            ps.setInt(3, u.getId());

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete (Integer id) {
        try (Connection conn = cu.getConnection()) {

            String sql = "delete from users where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) {
//        UserRepo u = new UserRepo();
//        User me = new User(5, "cbrooks", "333");
//        u.add(me);
//        u.getByUsername("cbrooks");
//    }



}
