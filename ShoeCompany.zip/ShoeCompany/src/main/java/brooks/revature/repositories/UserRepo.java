package brooks.revature.repositories;

import brooks.revature.models.User;
import brooks.revature.utils.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/*
 * Class will define methods to interact with our database.
 * C - Create
 * R _ Read
 * U - Update
 * D - Delete
 */
public class UserRepo implements CrudRepository<User>{
    //private static final Logger logger = LogManager.getLogManager(UserRepo.class);
    private ConnectionUtil cu = ConnectionUtil.getConnectionUtil();

    //Create
    public User add(User u) {
        try (Connection conn = cu.getConnection()) {
            String sql = "insert into users values(default, ?, ?, ?, ?, ?, 0) returning *";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, u.getUserName());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFirstName());
            ps.setString(4, u.getLastName());
            ps.setString(5, u.getEmployeeStatus());


            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                u.setId(rs.getInt("id"));

            }

        } catch(SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public User getById(Integer id) {
        try (Connection conn = cu.getConnection()) {

            String sql = "select * from users where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            // Same as getByUserName but different implementation
            if(rs.next()) {
                User u = new User();

                u.setId(rs.getInt("id"));
                u.setUserName(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setFirstName(rs.getString("first_name"));
                u.setLastName(rs.getString("last_name"));
                u.setEmployeeStatus(rs.getString("employee"));
                u.setFunds(rs.getInt("funds"));

                return u;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User getByUsername(String username) {

        try (Connection conn = cu.getConnection()) {

            String sql = "select * from users where username = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

// Same as getById but different implementation
            if (rs.next()) {
                User u = new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("employee"),
                        rs.getInt("funds")
                );
                return u;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }


    public List getAll() {ArrayList<User> a = new ArrayList();

        try (Connection conn = cu.getConnection()) {
            String sql = "select * from users";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                User u = new User(rs.getInt("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name")
                );

                a.add(u);
            }


        } catch(SQLException e) {
            e.printStackTrace();
        }

        return null;
    }


    public void update(User u) {
        try (Connection conn = cu.getConnection()) {
            String sql = "update users set username = ?, password = ?, first_name = ?, last_name = ?," +
                    "employee = ?, funds = ?, where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, u.getUserName());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFirstName());
            ps.setString(4, u.getLastName());
            ps.setString(5, u.getEmployeeStatus());
            ps.setInt(6, u.getId());

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete (Integer id) {
        try (Connection conn = cu.getConnection()) {

            String sql = "delete from users where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addFunds(Integer funds, String username) {
        try (Connection conn = cu.getConnection()) {

            String sql = "update users set funds = ? where username = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, funds);
            ps.setString(2, username);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) {
//        UserRepo u = new UserRepo();
//        User me = new User(1, "cbrooks", "333", "va", "ter", "", 0);
//        u.update(me);
//
//    }



}
