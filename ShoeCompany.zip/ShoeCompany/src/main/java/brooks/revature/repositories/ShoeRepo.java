package brooks.revature.repositories;

import brooks.revature.models.ShoeItem;
import brooks.revature.models.User;
import brooks.revature.utils.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShoeRepo {

    private ConnectionUtil cu = ConnectionUtil.getConnectionUtil();

    //Create
    public ShoeItem add(ShoeItem s) {
        try (Connection conn = cu.getConnection()) {
            String sql = "insert into inventory values(default, ?, ?, ?, ?, ?, ?) returning *";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getBrand());
            ps.setString(2, s.getName());
            ps.setString(3, s.getColor());
            ps.setString(4, s.getCategory());
            ps.setInt(5, s.getSize());
            ps.setInt(6, s.getPrice());

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                s.setid(rs.getInt("id"));
            }

        } catch(SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ShoeItem getById(Integer id) {
        try (Connection conn = cu.getConnection()) {

            String sql = "select * from inventory where id = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            // Same as getByUserName but different implementation
            if(rs.next()) {
                ShoeItem s = new ShoeItem();

                s.setid(rs.getInt("id"));
                s.setBrand(rs.getString("brand"));
                s.setName(rs.getString("name"));
                s.setColor(rs.getString("color"));
                s.setCategory(rs.getString("category"));
                s.setSize(rs.getInt("size"));
                s.setPrice(rs.getInt("price"));

                return s;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<ShoeItem> getAllShoes() {
        ArrayList<ShoeItem> a = new ArrayList();

        try (Connection conn = cu.getConnection()) {
            String sql = "select * from inventory";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                ShoeItem s = new ShoeItem();
                s.setBrand(rs.getString("brand"));
                s.setName(rs.getString("name"));
                s.setColor(rs.getString("color"));
                s.setCategory(rs.getString("category"));
                s.setSize(rs.getInt("size"));
                s.setPrice(rs.getInt("price"));

                a.add(s);
            }
            return a;


        } catch(SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void buyShoes (ShoeItem s) {
        try (Connection conn = cu.getConnection()) {

            String sql = "delete from inventory where brand = ? , name = ?, color = ?, category = ?" +
                    "size = ? price = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getBrand() );
            ps.setString(2, s.getName());
            ps.setString(3, s.getColor());
            ps.setString(4, s.getCategory());
            ps.setInt(5, s.getSize());
            ps.setInt(6, s.getPrice());

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void discount() {
        try (Connection conn = cu.getConnection()) {
            String sql = "update inventory set price = price / 2";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void regularPrice() {
        try (Connection conn = cu.getConnection()) {
            String sql = "update inventory set price = price * 2";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deactivateDiscount() {
        try (Connection conn = cu.getConnection()) {
            String sql = "update inventory set price = price * 2";

            PreparedStatement ps = conn.prepareStatement(sql);


            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
