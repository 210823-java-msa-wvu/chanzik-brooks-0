package brooks.revature.repositories;

import brooks.revature.models.ShoeItem;
import brooks.revature.utils.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ShoeRepo {

    private ConnectionUtil cu = ConnectionUtil.getConnectionUtil();

    //Create
    public ShoeItem add(ShoeItem s) {
        try (Connection conn = cu.getConnection()) {
            String sql = "insert into inventory values(default, ?, ?, ?, ?, ?,?) returning *";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getBrand());
            ps.setString(2, s.getName());
            ps.setString(3, s.getColor());
            ps.setString(4, s.getCategory());
            ps.setInt(5, s.getSize());
            ps.setInt(6, s.getPrice());

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                s.setId(rs.getInt("id"));

            }

        } catch(SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
